from pathlib import Path

from fractal_tasks_mock.input_models import InitArgsIllumination
from pydantic.decorator import validate_arguments


@validate_arguments
def illumination_correction_compute(
    *,
    zarr_url: str,
    init_args: InitArgsIllumination,
) -> dict:
    """
    Dummy task description.

    Arguments:
        zarr_url: description
        init_args: description
    """

    raw_zarr_url = init_args.raw_zarr_url
    subsets = init_args.subsets
    print("[illumination_correction_compute] START")
    print(f"[illumination_correction_compute] {zarr_url=}")
    print(f"[illumination_correction_compute] {raw_zarr_url=}")
    print(f"[illumination_correction_compute] {subsets=}")

    # Prepare output metadata
    if zarr_url == raw_zarr_url:
        out = dict(image_list_updates=[dict(zarr_url=zarr_url)])
    else:
        out = dict(image_list_updates=[dict(zarr_url=zarr_url, origin=raw_zarr_url)])
        print(f"[illumination_correction_compute] {zarr_url=}")

    with (Path(zarr_url) / "data").open("a") as f:
        f.write(
            f"[illumination_correction_compute] Running with {raw_zarr_url=}, "
            f"{subsets=}\n"
        )

    print("[illumination_correction_compute] END")
    return out


if __name__ == "__main__":
    from utils import run_fractal_task

    run_fractal_task(task_function=illumination_correction_compute)
