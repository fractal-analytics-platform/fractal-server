from typing import Optional

from fractal_tasks_mock.input_models import InitArgsGeneric
from pydantic import validate_call


@validate_call
def generic_compound_compute(
    *,
    zarr_url: str,
    init_args: InitArgsGeneric,
    another_argument: str,
    raise_error: bool = False,
) -> Optional[dict]:
    """
    Dummy task description.

    Arguments:
        zarr_url: description
        init_args: description
        another_argument: description
        raise_error: description
    """

    argument = init_args.argument
    print("[generic_compound_compute] START")
    print(f"[generic_compound_compute] {zarr_url=}")
    print(f"[generic_compound_compute] {argument=}")
    print(f"[generic_compound_compute] {another_argument=}")
    if raise_error:
        raise RuntimeError(f"{raise_error=}")

    print("[generic_compound_compute] END")
    return None


if __name__ == "__main__":
    from fractal_task_tools.task_wrapper import run_fractal_task

    run_fractal_task(task_function=generic_compound_compute)
