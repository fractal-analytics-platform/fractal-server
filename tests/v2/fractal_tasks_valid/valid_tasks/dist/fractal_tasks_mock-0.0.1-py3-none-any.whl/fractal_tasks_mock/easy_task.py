print("This is an easy task")
