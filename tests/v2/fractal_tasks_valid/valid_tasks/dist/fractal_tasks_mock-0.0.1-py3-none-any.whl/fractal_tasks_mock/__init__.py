print("easy task")
